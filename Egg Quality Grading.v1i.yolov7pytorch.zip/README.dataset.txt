# Egg Quality Grading > 2024-08-01 9:31am
https://universe.roboflow.com/ujjwals-workspace/egg-quality-grading-znzzq

Provided by a Roboflow user
License: CC BY 4.0

